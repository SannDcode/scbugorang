/*


██████╗░██╗██╗░░░░░██╗░░██╗███████╗ 
██╔══██╗██║██║░░░░░╚██╗██╔╝╚════██║ 
██║░░██║██║██║░░░░░░╚███╔╝░░░███╔═╝ 
██║░░██║██║██║░░░░░░██╔██╗░██╔══╝░░ 
██████╔╝██║███████╗██╔╝╚██╗███████╗ 
╚═════╝░╚═╝╚══════╝╚═╝░░╚═╝╚══════╝ 


*/

const fs = require('fs')

//~~~~~~~~~~~ Settings Owner ~~~~~~~~~~~//
global.owner = "6289506368777"
global.bot = ""
global.devname = "Dilxz Developer"
global.ownername = "Dilxz Official"
global.botname = "Vaeltrix Era"
global.versisc = "Versi 1.2 Pro"
global.packname = "⎋ Vaeltrix Execution"
global.footer = "⎋ Vaeltrix Execution - 2025"

//~~~~~~~~~~~ Settings Sosmed ~~~~~~~~~~~//
global.linkwa = "https://wa.me/6289506368777"
global.linkyt = "https://www.youtube.com/DilxzDev"
global.linktt = "https://tiktok.com/dilxzzdev"
global.linktele = "https://t.me/DilxzOffc"

//~~~~~~~~~~~ Settings Payment ~~~~~~~~~~~//
global.webpay = ""
global.dana = ""
global.gopay = ""
global.ovo = ""
global.qris = ""

//~~~~~~~~~~~ Settings Bot ~~~~~~~~~~~//
global.prefa = ["","!",".",",","#","/","🎭","〽️"]
global.autoRecording = true
global.autoTyping = true
global.autorecordtype = true
global.autoread = true
global.autobio = true
global.anti92 = true
global.owneroff = false
global.autoswview = true

//~~~~~~~~~~~ Settings Thumbnail ~~~~~~~~~~~//
global.thumbbot = "https://files.catbox.moe/gzrc5g.jpg"
global.thumbown = "https://files.catbox.moe/5iropa.jpg"

//~~~~~~~~~~~ Settings Channel ~~~~~~~~~~~//
global.idsaluran = "120363330289360382@newsletter"
global.namasaluran = "DilxzOffc || Vaeltrix Dev"
global.channel = "https://whatsapp.com/channel/0029VanRJcU7NoaADR1oyb2v"

//~~~~~~~~~~~ Settings Message ~~~~~~~~~~~//
global.mess = {
    developer: "    \`[ Developer Only!! ]\` \n Fitur Ini Untuk Developer Dilxz!!", 
	owner: "    \`[ Owner Only!! ]\` \n Fitur Ini Untuk Owner Dilxz!!", 
	prem: "    \`[ Premium Only!! ]\` \n Fitur Ini Untuk Premium Dilxz!!",
	murbug: "    \`[ Murbug Only!! ]\` \n Fitur Ini Untuk Murbug Dilxz!!",
	group: "    \`[ Group Only!! ]\` \n Fitur Ini Untuk Group Chat Dilxz!!",
	private: "    \`[ Private Only!! ]\` \n Fitur Ini Untuk Private Chat Dilxz!!",
	admin: "    \`[ Admin Only!! ]\` \n Fitur Ini Untuk Admin Dilxz!!",
	botadmin: "    \`[ Bot Admin Only!! ]\` \n Fitur Ini Untuk Bot Admin Dilxz!!", 
	wait: "    \`[ Wait!! ]\` \n Sabar Lagi Loading Dilxz!!!",
	error: "    \`[ Error!! ]\` \n Fitunya Error Dilxz!!!",
	done: "    \`[ Done!! ]\` \n Proses Done Dilxz!!!"
}

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
